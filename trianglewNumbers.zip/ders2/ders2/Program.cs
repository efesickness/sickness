﻿Console.WriteLine("Sayı Giriniz: ");
int a = Convert.ToInt32(Console.ReadLine());
int sayac = 0;


    for (int j = a; j > 0; j--)
    {

    if (j != a)
    {
        for (int i = 0; i < 2*(a - j); i++)
        {
            Console.Write(" ");
        }
    }
        while (sayac < j)
        {

            Console.Write((sayac += 1) + " ");

        }
        sayac = j;

        while (sayac > 1)
        {

            Console.Write((sayac -= 1) + " ");

        }
        sayac = 0;
    Console.Write("\n");
    }